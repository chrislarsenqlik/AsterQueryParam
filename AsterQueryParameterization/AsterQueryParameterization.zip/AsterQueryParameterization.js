var socketio_port = 33333;


require.config({
        paths: {
            socketio: 'http://localhost:'+socketio_port+'/socket.io/socket.io'
        }
});

define( ["jquery", "text!./style.css","qlik", "socketio"], function ( $, cssContent, qlik, io ) {
	'use strict';
	$( "<style>" ).html( cssContent ).appendTo( "head" );
	return {
        initialProperties : {
            version: 1.0,
            qHyperCubeDef : {
                qDimensions : [],
                qMeasures : [],
                qInitialDataFetch : [{
                    qWidth : 1,
                    qHeight : 500
                }]
            }
        },
		definition: {
			type: "items",
			component: "accordion",
			items: {
                dimensions : {
                    uses : "dimensions",
                    min : 1,
                    max: 1
                },
				sorting: {
					uses: "sorting"
				},
				settings: {
					uses: "settings"
				}
			}
		},
		snapshot: {
			canTakeSnapshot: false
		},
        resize: function() {
        },
		paint: function ( $element,layout ) {

             var _this = this;
             var qData = layout.qHyperCube.qDataPages[0];
             var qMatrix = qData.qMatrix;
             var qDimInfo = this.backendApi.getDimensionInfos();
             var qDimName = qDimInfo[0].qFallbackTitle
             //console.log(qDimName);

             var app = qlik.currApp();
             var thisAppId = app.id;

             var reloadTaskName = 'Reload Breaking Bad'
             var socket = io.connect('http://localhost:'+socketio_port);
             var socketstatus;
             if (socket) {
                socketstatus = 'Connected'
             } else {
                socketstatus = 'Not Connected'
             }

            socket.on( 'connect', function(err) {
                console.log('connected to socket.io')
                if (err) {
                    console.log(err);
                } else {
                    
                }

            });

             var paramValues = {};
             var OptionVal1="";
             var OptionVal2="";
             var InputVal1="";
             var InputVal2="";

             // var divHtml = $("#" + divName);
             // console.info(divHtml);
             var html = "<div id='notifybar' style='background-color:white;' align='center'>Change Parameter Values</div>";
                 html += "<div align='center' class='parambody'>"+qDimName+"<br>";
                 html += "<select name=select1 id='select1'><option>ChooseOne</option>";

             qMatrix.forEach( function(d){
                html +="<option>"+d[0].qText+"</option>"
                console.log(d[0].qText)
             });
                 html+= "</select><br><br>";
                 html += "# of Minutes Window<br>";
                 //divHtml.innerHTML += this.Layout.Text2.text+"<br>";
                 html += "<input  id='input1' class='inputclass' name='input1' value='' size='4' value='20'><br>";
                 html +="<button id='submit' class='myButton'>Submit</button></div>"

                 // html += "test Text 4<br>";
                 // html += "<input id='input2' name='input2' value=''><br><br>";
                 //html += "";
                 

                 paramValues = {};
     //              divHtml.style.width = "180px";
                 // divHtml.style.height = "300px";
                  console.info(html);
                 //divHtml.css("overflow","hidden");
                 
                 //divHtml.innerHTML = this.Layout.Text0.text+"<br>";
                
                 $element.html(html); 
                 $element.attr('class','queryparam');                //setProps(divHtml, this);
                 //this.Element.appendChild(divHtml);
                 //this.divCreated = true;

                 OptionVal1=$('#select1').val();
                 OptionVal2=$('#select2').val();
                 InputVal1=$('#input1').val();
                 InputVal2=$('#input2').val();

                $('#select1').change(function(){
                        console.log('select 1 changed')
                        app.variable.setContent("vEventTypeExt",$('#select1').val());
                        //qvDoc.SetVariable("vOptionVal1", $('#select1').val());
                        console.log($('#select1').val())
                });

                // $('#select2').change(function(){
                //         console.log('select 2 changed')
                //         console.log($('#select2').val())
                //         app.variable.setContent("vOptionVal2", $('#select2').val());
                // });

                $('#input1').change(function(){
                    console.log('input2 changed')
                    console.log($('#input1').val())
                    app.variable.setContent("vMinutesExt", $('#input1').val());
                });

                // $('#input2').change(function(){
                //     console.log('input2 changed')
                //     console.log($('#input2').val())
                //     app.variable.setContent("vInputVal2", $('#input2').val());
                // });

                $('#submit').click(function(){
                    socket.emit('reload app',{'taskname': reloadTaskName, 'tvshow':$('#select1').val(),'minutes': $('#input1').val()})
                    console.log('clicked')
                });



                //console.log('new user part: '+ThisUser)
                socket.emit('new appuser', {'nick' : 'aster', 'appid': thisAppId});

                console.log('app id: '+thisAppId);
                //socket.join(ThisAppId);
                socket.on('reload status', function(data, callback){
                    console.log('got reload status')
                    console.log(data)
                    
                    if (data ==='Task Reload Succeeded') {
                        $('#notifybar').empty();
                        $('#notifybar').append('Task Reload Succeeded').fadeIn();;
                        $('#notifybar').delay(3000).fadeOut();

                    } else {
                        $('#notifybar').empty();
                        $('#notifybar').append(data).fadeIn();
                    }   
                });

        
		}
	};
} );
